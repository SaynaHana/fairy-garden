#include "attack_data.h"

namespace game {
	AttackData::AttackData(float attack_interval) {
		attack_interval_ = attack_interval;
	}
}