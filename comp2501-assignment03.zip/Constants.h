#ifndef CONSTANTS_H
#define CONSTANTS_H


// CHANGE: collision types
enum CollisionType {
    circle_ = 0,
    ray_ = 1
};

#endif
