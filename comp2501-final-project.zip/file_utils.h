#ifndef FILE_UTILS_H_
#define FILE_UTILS_H_

#include <string>

namespace game {

    std::string LoadTextFile(const char *filename);

} // namespace game

#endif // FILE_UTILS_H_
